## Customer_Info

First Name: Jane 
Last Name: Doe 
Age: 28 
Email Address: janedoe@example.com 
Phone Number: 555-987-6543 
Shipping Address: 456 Oak St, Another City USA, 67890 
Membership: Gold 

## Recent_Purchases

order_number: 6 
date: 2023-01-10 
item:
- description:  Adventurer Pro Backpack, quantity 1, price $90 
  item_number: 2 

order_number: 15 
date: 2023-01-20 
item:
- description:  TrekReady Hiking Boots, quantity 1, price $140 
  item_number: 4 

order_number: 23 
date: 2023-01-30 
item:
- description:  EcoFire Camping Stove, quantity 1, price $80 
  item_number: 6 

order_number: 32 
date: 2023-02-15 
item:
- description:  SummitClimber Backpack, quantity 1, price $120 
  item_number: 9 

order_number: 44 
date: 2023-03-06 
item:
- description:  PowerBurner Camping Stove, quantity 1, price $100 
  item_number: 13 

order_number: 53 
date: 2023-03-21 
item:
- description:  TrailLite Daypack, quantity 1, price $60 
  item_number: 16 

order_number: 62 
date: 2023-04-06 
item:
- description:  Adventure Dining Table, quantity 1, price $90 
  item_number: 19 

