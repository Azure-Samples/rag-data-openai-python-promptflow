## Customer_Info

First Name: Robert 
Last Name: Johnson 
Age: 36 
Email Address: robertj@example.com 
Phone Number: 555-555-1212 
Shipping Address: 123 Main St,  Anytown USA, 12345 
Membership: None 

## Recent_Purchases

order_number: 10 
date: 2023-05-05 
item:
- description:  Adventurer Pro Backpack, quantity 2, price $180 
  item_number: 2 

