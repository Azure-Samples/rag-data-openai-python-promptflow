## Customer_Info

First Name: Michael 
Last Name: Johnson 
Age: 45 
Email Address: michaelj@example.com 
Phone Number: 555-555-1212 
Shipping Address: 789 Elm St,  Smallville USA, 34567 
Membership: None 

## Recent_Purchases

order_number: 11 
date: 2023-01-15 
item:
- description:  Summit Breeze Jacket, quantity 1, price $120 
  item_number: 3 

order_number: 20 
date: 2023-02-28 
item:
- description:  BaseCamp Folding Table, quantity 2, price $120 
  item_number: 5 

order_number: 30 
date: 2023-03-15 
item:
- description:  Alpine Explorer Tent, quantity 1, price $350 
  item_number: 8 

order_number: 38 
date: 2023-02-25 
item:
- description:  TrailWalker Hiking Shoes, quantity 1, price $110 
  item_number: 11 

order_number: 47 
date: 2023-03-11 
item:
- description:  MountainDream Sleeping Bag, quantity 1, price $130 
  item_number: 14 

order_number: 60 
date: 2023-05-06 
item:
- description:  TrekStar Hiking Sandals, quantity 2, price $140 
  item_number: 18 

