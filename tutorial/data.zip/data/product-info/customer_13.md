## customer_info  
  
name: Seth Juarez   
age: 28    
phone_number: 555-987-6543    
email: seth.juarez@example.com    
address: 789 Broadway St, Seattle, WA 98101  
  
loyalty_program: True    
loyalty_program Level: Bronze    
  
## recent_purchases  
  
order_number: 5 
date: 2023-05-01 
item:
- description:  TrailMaster X4 Tent, quantity 1, price $250 
  item_number: 1 

order_number: 18 
date: 2023-05-04 
item:
- description:  Pathfinder Pro-1 Adventure Compass, quantity 1, price $39.99 
  item_number: 66 

order_number: 28 
date: 2023-04-15 
item:
- description:  CozyNights Sleeping Bag, quantity 1, price $100 
  item_number: 7 
